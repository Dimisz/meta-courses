//
//  MenuCategory.swift
//  LittleLemonMenu
//
//  Created by VS on 18.02.23.
//

import Foundation

enum MenuCategory: String {
    case food = "Food"
    case drink = "Drink"
    case dessert = "Dessert"
}
