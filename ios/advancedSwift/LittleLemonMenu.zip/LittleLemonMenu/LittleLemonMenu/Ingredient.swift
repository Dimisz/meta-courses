//
//  Ingredient.swift
//  LittleLemonMenu
//
//  Created by VS on 18.02.23.
//

import Foundation

enum Ingredient: String, CaseIterable {
    case spinach = "Spinach"
    case broccoli = "Broccoli"
    case carrot = "Carrot"
    case pasta = "Pasta"
    case tomatoSauce = "Tomato Sauce"
}
