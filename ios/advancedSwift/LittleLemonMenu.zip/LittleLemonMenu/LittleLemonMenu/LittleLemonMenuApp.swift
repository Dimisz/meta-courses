//
//  LittleLemonMenuApp.swift
//  LittleLemonMenu
//
//  Created by VS on 18.02.23.
//

import SwiftUI

@main
struct LittleLemonMenuApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
