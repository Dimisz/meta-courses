//
//  LittleLemonApp.swift
//  LittleLemon
//
//  Created by VS on 16.02.23.
//

import SwiftUI

@main
struct LittleLemonApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
